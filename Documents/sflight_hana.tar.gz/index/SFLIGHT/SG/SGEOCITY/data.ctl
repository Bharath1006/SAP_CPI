import data
into table "SFLIGHT"."SGEOCITY"
from 'data.csv'
    record delimited by '\n'
    field delimited by ','
    optionally enclosed by '"'
error log 'data.err'
